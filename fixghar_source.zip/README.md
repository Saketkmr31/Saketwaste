# FixGhar — Home Repair Companion

**Version 1.0** · Installable Android WebView application + offline-capable standalone PWA.

FixGhar is a mobile-first home repair knowledge base with **41 symptom-oriented tutorials** in 13 categories: generators, televisions, fans, air coolers, air conditioners, refrigerators, washing machines, inverters, home electrical safety, Wi-Fi/CCTV, kitchen appliances, geysers/plumbing, gadgets, and more.

## Features

- Search using appliance/symptom keywords (English, Hinglish and common Devanagari keywords); opens the best-matched guide directly when confidence is high; otherwise shows relevant results.
- 41 locally bundled text tutorials, each with hazard notices and trackable checklist steps.
- YouTube player embeds for three curated references and a per-guide **add/change YouTube URL** field. Online video search links for all guides. Video playback requires internet and depends on YouTube allowing embedding.
- Progress tracking, bookmarks, recent guides, local brand/model notes, speech playback when supported, Android speech search, share, and backup import/export.
- Add your own guide with steps and video link.
- Open Google, YouTube and Reddit searches for topics not available in the offline library.
- Offline content persists without an account. No tracker, account, or proprietary API key.
- Sensitive work (wiring, capacitors, breaker boxes, mains, inverters and generators) explicitly routes to qualified professionals.

## How to compile an APK

Android SDK build tools are **not included in this ZIP**. To compile:

1. Open the root `FixGhar-Android` folder as a project in **Android Studio** (JDK 17, Android SDK 35).
2. Let Gradle sync. Gradle 8.7 and Android Gradle Plugin 8.6.1 are used.
3. Choose **Build → Build APK(s)** or from CLI with Gradle 8.7 run `gradle assembleDebug`.
4. Find your installable debug APK at `app/build/outputs/apk/debug/app-debug.apk`.
5. On your phone, permit installing APKs from your trusted file manager, then install the APK. Do not upload debug APK to Play Store; generate a signed AAB with your own release key for production.

### GitHub Actions option

Push this project into a **new dedicated GitHub repo** with Actions enabled. The supplied `.github/workflows/build-apk.yml` builds a debug APK, then makes it downloadable at **Actions → Build FixGhar APK → run → Artifacts → FixGhar-Android-debug-APK**. GitHub may require signing in to download artifacts.

## Run the web version (local development)

From `app/src/main/assets/` run `python -m http.server 8000` and open `http://localhost:8000/` in a browser. To install as a PWA, host the folder on HTTPS, then choose browser **Add to Home Screen**.

## Limitations and responsible use

**This is a first build / MVP, not an AI diagnosis service or universal live repair search engine.** Search works across bundled & user-created guides. If there is no match, Google/YouTube/Reddit searches open externally. Automatic YouTube search + selecting videos inside the app would require a backend and the official YouTube Data API; embedding without permission or making up video IDs is not supported. Four other planned expansions are model-specific manufacturer manual lookup, sourced live guide catalog, error-code database, and photo-assisted diagnosis.

Content is educational and is not a substitute for product manuals or a professional. Dangerous repairs must be performed by qualified service professionals. The app has no telemetry and only uses Android INTERNET permission for video/external resources.

## Sources that informed this build

- iFixit repair app — symptom-oriented step guides and repair library: https://www.ifixit.com/go/App
- r/appliancerepair model-number advice: https://www.reddit.com/r/appliancerepair/comments/1dh5x59/
- YouTube iframe guidance: https://support.google.com/youtube/answer/171780
- Electrical Safety Foundation International: https://www.esfi.org/do-it-yourself-diy-electrical-safety/
- CPSC generator safety: https://www.cpsc.gov/Safety-Education/Safety-Guides/Carbon-Monoxide-Home/Generators-and-Engine-Driven-Tools

Built-in YouTube IDs were discovered for TV No Signal, fridge not cooling, and washer drain; external creators retain all rights to their videos.
