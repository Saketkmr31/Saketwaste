package in.fixghar.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;

/** Minimal Android shell around a bundled, offline repair knowledge base.
 * Local content is isolated under an HTTPS appassets origin; off-origin links open in browser.
 */
public class MainActivity extends Activity {
    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final int SPEECH_REQUEST = 1901;
    private FrameLayout root;
    private WebView web;
    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(10,17,27));
        getWindow().setNavigationBarColor(Color.rgb(10,17,27));
        root = new FrameLayout(this);
        setContentView(root);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setSupportMultipleWindows(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setBackgroundColor(Color.rgb(10,17,27));
        web.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request){
                Uri uri = request.getUrl();
                if (!"https".equals(uri.getScheme()) || !APP_HOST.equals(uri.getHost())) return null;
                String path = uri.getPath();
                if (path == null) return forbidden();
                if ("/".equals(path)) path = "/index.html";
                if (path.contains("..") || path.indexOf('\\')>=0) return forbidden();
                String asset=path.substring(1);
                try {
                    InputStream in = getAssets().open(asset);
                    String mime=asset.endsWith(".html")?"text/html":asset.endsWith(".js")?"application/javascript":asset.endsWith(".css")?"text/css":asset.endsWith(".json")||asset.endsWith(".webmanifest")?"application/json":asset.endsWith(".svg")?"image/svg+xml":asset.endsWith(".png")?"image/png":"application/octet-stream";
                    return new WebResourceResponse(mime, mime.startsWith("image/")?null:"UTF-8",in);
                } catch (IOException e) {return forbidden();}
            }
            private WebResourceResponse forbidden(){return new WebResourceResponse("text/plain","UTF-8", 404, "Not Found",java.util.Collections.emptyMap(),new java.io.ByteArrayInputStream(new byte[0]));}
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){
                if (!request.isForMainFrame())return false;
                Uri uri=request.getUrl();
                if ("https".equals(uri.getScheme())&&APP_HOST.equals(uri.getHost()))return false;
                String scheme=uri.getScheme();
                if ("https".equals(scheme)||"http".equals(scheme)){
                    try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception e){Toast.makeText(MainActivity.this,"No browser found",Toast.LENGTH_SHORT).show();}
                }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public void onShowCustomView(View view, CustomViewCallback callback){
                if(customView!=null){callback.onCustomViewHidden();return;}
                customView=view;customCallback=callback;
                web.setVisibility(View.GONE);
                root.addView(view,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            }
            @Override public void onHideCustomView(){
                if(customView==null)return;
                root.removeView(customView);customView=null;
                if(customCallback!=null)customCallback.onCustomViewHidden();customCallback=null;
                web.setVisibility(View.VISIBLE);
                getWindow().getDecorView().setSystemUiVisibility(0);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
            }
        });
        web.addJavascriptInterface(new Object(){
            @JavascriptInterface public void startVoice(String locale){
                runOnUiThread(()->{
                    Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN".equals(locale)?"en-IN":"hi-IN");
                    i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Apna repair problem boliye");
                    try{startActivityForResult(i,SPEECH_REQUEST);}catch(ActivityNotFoundException ex){Toast.makeText(MainActivity.this,"Speech recognizer unavailable. Type instead.",Toast.LENGTH_LONG).show();}
                });
            }
        },"FixGharVoice");
        web.loadUrl("https://"+APP_HOST+"/index.html");
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==SPEECH_REQUEST&&resultCode==RESULT_OK&&data!=null){
            ArrayList<String> guesses=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if(guesses!=null&&!guesses.isEmpty())web.evaluateJavascript("window.fixgharVoiceResult("+JSONObject.quote(guesses.get(0))+")",null);
        }
    }
    @Override public void onBackPressed(){
        if(customView!=null){hideFullscreen();return;}
        String js="(function(){if(location.hash&&location.hash!=='#/'&&location.hash!==''){location.hash='#/';return true;}return false;})()";
        web.evaluateJavascript(js, value->{if(!"true".equals(value))MainActivity.super.onBackPressed();});
    }
    private void hideFullscreen(){
        if(customView==null)return;
        root.removeView(customView);customView=null;
        if(customCallback!=null)customCallback.onCustomViewHidden();customCallback=null;
        web.setVisibility(View.VISIBLE);
        getWindow().getDecorView().setSystemUiVisibility(0);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }
    @Override protected void onDestroy(){ if(web!=null){root.removeView(web);web.destroy();web=null;}super.onDestroy();}
}
